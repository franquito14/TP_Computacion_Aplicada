#!/bin/bash

# Directorios de origen permitidos y directorio de destino fijo
DIR_DESTINO="/backup_dir"
DIR_ORIGEN=$1

# Validar que el directorio de origen sea /var/logs o /www_dir
if [[ "$DIR_ORIGEN" != "/var/logs" && "$DIR_ORIGEN" != "/www_dir" ]]; then
    echo "Error: El directorio de origen debe ser /var/logs o /www_dir."
    exit 1
fi

# Validar que el directorio de origen exista y esté montado
if [[ ! -d "$DIR_ORIGEN" || ! "$(ls -A $DIR_ORIGEN 2>/dev/null)" ]]; then
    echo "Error: El directorio de origen $DIR_ORIGEN no existe o está vacío."
    exit 1
fi

# Validar que el directorio de destino exista y esté montado
if [[ ! -d "$DIR_DESTINO" || ! "$(ls -A $DIR_DESTINO 2>/dev/null)" ]]; then
    echo "Error: El directorio de destino $DIR_DESTINO no existe o no está disponible."
    exit 1
fi

# Generar nombre de archivo de respaldo con la fecha actual en formato YYYYMMDD
NOMBRE_BACKUP="$(basename "$DIR_ORIGEN")_bkp_$(date +%Y%m%d).tar.gz"

# Crear el backup
tar -czf "$DIR_DESTINO/$NOMBRE_BACKUP" "$DIR_ORIGEN" && echo "Backup de $DIR_ORIGEN completado en $DIR_DESTINO/$NOMBRE_BACKUP"


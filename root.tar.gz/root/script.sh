#!/bin/bash

echo "hola mundo"

VAR=vicen
echo "El mejor es"$VAR

DATE='date'

echo $DATE
